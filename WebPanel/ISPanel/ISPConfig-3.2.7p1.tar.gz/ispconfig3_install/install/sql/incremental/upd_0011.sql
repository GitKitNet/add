-- use text for groups
ALTER TABLE `sys_user` CHANGE `groups` `groups` TEXT;
