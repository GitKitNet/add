ALTER TABLE  `sys_datalog` CHANGE  `data`  `data` LONGTEXT NOT NULL;

