#!/bin/sh

echo "This script is no longer used. Use the cron.sh instead."
