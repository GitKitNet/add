#!/bin/bash

echo "This script is no longer used. Please use ispconfig_update.sh instead." ;

exit 1;
