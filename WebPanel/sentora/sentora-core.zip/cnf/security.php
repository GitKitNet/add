<?php

/**
 * @copyright 2014-2019 Sentora Project (http://www.sentora.org/) 
 * Sentora is a GPL fork of the ZPanel Project whose original header follows:
 *
 * Security configuration file.
 * @package zpanelx
 * @subpackage core -> config
 * @author Bobby Allen (ballen@bobbyallen.me)
 * @copyright ZPanel Project (http://www.zpanelcp.com/)
 * @link http://www.zpanelcp.com/
 * @license GPL (http://www.gnu.org/licenses/gpl.html)
 */
global $security;

$security['server_crypto_key'] = "GENERATED_SALT_HERE";
