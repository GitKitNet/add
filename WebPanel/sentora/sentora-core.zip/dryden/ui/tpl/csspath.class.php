<?php

/**
 * @copyright 2014-2019 Sentora Project (http://www.sentora.org/) 
 * Sentora is a GPL fork of the ZPanel Project whose original header follows:
 *
 * Generic template place holder class.
 * @package zpanelx
 * @subpackage dryden -> ui -> tpl
 * @version 1.0.0
 * @author Bobby Allen (ballen@bobbyallen.me)
 * @copyright ZPanel Project (http://www.zpanelcp.com/)
 * @link http://www.zpanelcp.com/
 * @license GPL (http://www.gnu.org/licenses/gpl.html)
 */
class ui_tpl_csspath {

    public static function Template() {
        $user = ctrl_users::GetUserDetail();
        if (!fs_director::CheckForEmptyValue(fs_director::CheckForEmptyValue($user['usercss']))) {
            $retval = "etc/styles/" . ui_template::GetUserTemplate() . "/css/default.css";
        } else {
            $retval = "etc/styles/" . ui_template::GetUserTemplate() . "/css/" . $user['usercss'] . ".css";
        }
        return $retval;
    }

}

?>
