<?php /* Smarty version 2.6.30, created on 2017-05-23 03:01:48
         compiled from inc/header.tpl */ ?>
<html>
    <body>