<?php /* Smarty version 2.6.30, created on 2017-06-02 16:38:53
         compiled from logon.tpl */ ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'inc/header.tpl', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>

<h1>Login</h1>

<form method="post">
    <input type="hidden" name="goto" value="oauth.php" />

    <label for="username">User name</label><br />
    <input type="text" name="username" id="username" />
    
    <br /><br />

    <label for="password">Password</label><br />
    <input type="text" name="password" id="password" />

    <br /><br />
    
    <input type="submit" value="Login" />
</form>

<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'inc/footer.tpl', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>