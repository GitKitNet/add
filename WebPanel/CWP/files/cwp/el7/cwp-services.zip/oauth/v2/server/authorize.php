<?php
/**
 * Created by PhpStorm.
 * User: jose
 * Date: 08/06/17
 * Time: 06:39 AM
 */
// include our OAuth2 Server object
require_once __DIR__.'/server.php';

$request = OAuth2\Request::createFromGlobals();
$response = new OAuth2\Response();

// validate the authorize request
if (!$server->validateAuthorizeRequest($request, $response)) {
    $response->send();
    die;
}


// print the authorization code if the user has authorized your client
//$is_authorized = ($_POST['authorized'] == 'yes');
$is_authorized = true;
$server->handleAuthorizeRequest($request, $response, $is_authorized);
//if ($is_authorized) {
    // this is only here so that you get to see your code in the cURL request. Otherwise, we'd redirect back to the client
  $code = substr($response->getHttpHeader('Location'), strpos($response->getHttpHeader('Location'), 'code=')+5, 40);
    //exit("SUCCESS! Authorization Code: $code");
//}
$response->send();
echo json_encode(array('success' => true, 'code' => $code));


