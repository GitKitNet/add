#!/bin/bash

cd /usr/local/src
rm -rf mcrypt*
wget https://pecl.php.net/get/mcrypt-1.0.1.tgz
tar -xf mcrypt-*
cd mcrypt-*/
phpize
./configure
make
make install
touch /usr/local/php/php.d/mcrypt.ini
grep "mcrypt.so" /usr/local/php/php.d/mcrypt.ini 2> /dev/null 1> /dev/null|| echo "extension=mcrypt.so" >> /usr/local/php/php.d/mcrypt.ini
