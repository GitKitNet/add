#!/bin/bash

cd /usr/local/src
rm -rf intl-3.0.0.tgz
rm -rf intl-3.0.0
wget https://pecl.php.net/get/intl-3.0.0.tgz
tar -zxvf intl-3.0.0.tgz
cd intl-3.0.0
phpize
./configure
make
make install
grep "intl.so" /usr/local/php/php.ini 2> /dev/null 1> /dev/null|| echo "extension=intl.so" >> /usr/local/php/php.ini