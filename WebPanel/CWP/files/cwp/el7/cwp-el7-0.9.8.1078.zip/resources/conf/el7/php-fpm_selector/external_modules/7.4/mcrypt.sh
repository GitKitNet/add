#!/bin/bash

cd /usr/local/src
rm -rf mcrypt*
wget https://pecl.php.net/get/mcrypt-1.0.3.tgz
tar -xf mcrypt-*
cd mcrypt-*/
phpize
./configure --with-php-config=/opt/alt/php-fpm74/usr/bin/php-config
make
make install
touch /opt/alt/php-fpm74/usr/php/php.d/mcrypt.ini
grep "mcrypt.so" /opt/alt/php-fpm74/usr/php/php.d/mcrypt.ini 2> /dev/null 1> /dev/null|| echo "extension=mcrypt.so" >> /opt/alt/php-fpm74/usr/php/php.d/mcrypt.ini
