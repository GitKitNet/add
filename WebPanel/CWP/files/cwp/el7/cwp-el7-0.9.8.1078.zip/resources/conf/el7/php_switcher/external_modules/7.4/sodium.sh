#!/bin/bash

yum --enablerepo=epel -y install libsodium libsodium-devel
cd /usr/local/src
rm -rf libsodium*
curl https://pecl.php.net/get/libsodium -o libsodium.tgz
tar zxf libsodium.tgz
cd libsodium-*/
phpize
./configure
make
make install
echo ""
grep "sodium.so" /usr/local/php/php.ini 2> /dev/null 1> /dev/null|| echo "extension=sodium.so" >> /usr/local/php/php.ini
