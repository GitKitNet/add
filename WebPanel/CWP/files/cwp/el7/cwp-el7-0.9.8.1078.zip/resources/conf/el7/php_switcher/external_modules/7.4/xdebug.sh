#!/bin/bash

cd /usr/local/src
rm -rf xdebug*
wget https://github.com/xdebug/xdebug/archive/master.zip -O xdebug.zip
unzip xdebug.zip
cd xdebug-*/
phpize
./configure
make
make && make install
touch /usr/local/php/php.d/xdebug.ini
grep "xdebug.so" /usr/local/php/php.d/xdebug.ini 2> /dev/null 1> /dev/null|| echo "zend_extension=xdebug.so" >> /usr/local/php/php.d/xdebug.ini
