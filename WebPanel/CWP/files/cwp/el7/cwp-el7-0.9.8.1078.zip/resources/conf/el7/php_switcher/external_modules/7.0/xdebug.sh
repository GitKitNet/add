#!/bin/bash

cd /usr/local/src
rm -rf xdebug*
wget https://pecl.php.net/get/xdebug-2.9.0.tgz -O xdebug.tgz
tar zxf xdebug.tgz
cd xdebug-*/
phpize
./configure
make
make && make install
touch /usr/local/php/php.d/xdebug.ini
grep "xdebug.so" /usr/local/php/php.d/xdebug.ini 2> /dev/null 1> /dev/null|| echo "zend_extension=xdebug.so" >> /usr/local/php/php.d/xdebug.ini
