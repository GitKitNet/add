#!/bin/bash

yum -y install memcached

cd /usr/local/src
rm -rf memcache-2.2.7
rm -rf memcache-2.2.7.tgz
wget http://pecl.php.net/get/memcache-2.2.7.tgz
tar -zxvf memcache-2.2.7.tgz
cd memcache-2.2.7
phpize
./configure
make
make install
sed -i '/\<extension=memcached.so\>/d' /usr/local/php/php.ini
grep "memcache.so" /usr/local/php/php.ini 2> /dev/null 1> /dev/null|| echo "extension=memcache.so" >> /usr/local/php/php.ini

systemctl restart httpd
systemctl restart memcached
systemctl enable memcached
