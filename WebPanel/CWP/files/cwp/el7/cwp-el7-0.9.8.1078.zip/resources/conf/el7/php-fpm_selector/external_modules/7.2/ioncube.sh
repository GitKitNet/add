#!/bin/bash

if [ -e "/opt/alt/php-fpm72/usr/bin/php-config" ];then
cd /usr/local/src
rm -rf ioncube
rm -rf /usr/local/ioncube
mkdir /usr/local/ioncube
wget http://downloads.ioncube.com/loader_downloads/ioncube_loaders_lin_x86-64.zip
unzip ioncube_loaders_lin_x86-64.zip
cd ioncube
yes | cp -rv * /usr/local/ioncube
rm -rf /opt/alt/php-fpm72/usr/php/php.d/ioncube.ini
touch /opt/alt/php-fpm72/usr/php/php.d/ioncube.ini
#grep "ioncube_loader_lin_7.2.so" /usr/local/php/php.ini || echo "zend_extension=/usr/local/ioncube/ioncube_loader_lin_7.2.so" >> /usr/local/php/php.ini
#echo "zend_extension=/usr/local/ioncube/ioncube_loader_lin_7.2.so" > /opt/alt/php-fpm72/usr/php/php.d/ioncube.ini
grep "ioncube_loader_lin_7.2.so" /opt/alt/php-fpm72/usr/php/php.d/ioncube.ini 2> /dev/null 1> /dev/null|| echo "zend_extension=/usr/local/ioncube/ioncube_loader_lin_7.2.so" > /opt/alt/php-fpm72/usr/php/php.d/ioncube.ini
else
echo "Skipping as php build failed"
fi
