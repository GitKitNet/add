#!/bin/bash

cd /usr/local/src
wget http://ftp.indexdata.dk/pub/yaz/yaz-5.28.0.tar.gz -O yaz.tar.gz
tar -zxvf yaz.tar.gz
cd yaz-*/
./configure
make
make install
cd /usr/local/src
curl https://pecl.php.net/get/yaz -o yaz.tgz
tar -zxvf yaz.tgz
cd yaz-*/
phpize
./configure
make
make install
rm -rf yaz*
sed --in-place '/extension_dir=/d' /usr/local/php/php.ini
grep "yaz.so" /usr/local/php/php.ini 2> /dev/null 1> /dev/null|| echo "extension=yaz.so" >> /usr/local/php/php.ini


