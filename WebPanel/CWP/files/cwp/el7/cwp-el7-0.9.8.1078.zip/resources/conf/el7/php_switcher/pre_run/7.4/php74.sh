#/bin/bash

rm -Rf /usr/local/src/pcre2.zip /usr/local/src/pcre2* 2> /dev/null
cd /usr/local/src
wget https://ftp.pcre.org/pub/pcre/pcre2-10.34.zip -O pcre2.zip
unzip pcre2.zip
cd pcre2-*/
./configure
make && make install
