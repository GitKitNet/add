#!/bin/bash

cd /usr/local/src
rm -rf phar-2.0.0.tgz
rm -rf phar-2.0.0
wget https://pecl.php.net/get/phar-2.0.0.tgz
tar -zxvf phar-2.0.0.tgz
cd phar-2.0.0
phpize
./configure
make
make install
grep "phar.so" /usr/local/php/php.ini 2> /dev/null 1> /dev/null|| echo "extension=phar.so" >> /usr/local/php/php.ini