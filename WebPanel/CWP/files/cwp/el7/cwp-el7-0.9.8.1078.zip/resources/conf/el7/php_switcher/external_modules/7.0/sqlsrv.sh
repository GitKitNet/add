#!/bin/bash

cd /usr/local/src
yum install unixODBC unixODBC-devel -y
rm -rf sqlsrv*
wget https://pecl.php.net/get/sqlsrv-5.3.0.tgz
tar -xf sqlsrv-*
cd sqlsrv-*/
phpize
./configure
make
make install

PHPEXTDIR=`/usr/local/bin/php-config --extension-dir`

if [ -e "$PHPEXTDIR/sqlsrv.so" ];then 
	echo "Creating config file"
	grep "sqlsrv.so" /usr/local/php/php.ini 2> /dev/null 1> /dev/null|| echo "extension=sqlsrv.so" >> /usr/local/php/php.ini
else
	echo "ERROR: Missing extension file $PHPEXTDIR/sqlsrv.so"
fi

rm -rf pdo_sqlsrv*
wget https://pecl.php.net/get/pdo_sqlsrv-5.3.0.tgz
tar -xf pdo_sqlsrv-*
cd pdo_sqlsrv-*/
phpize
./configure
make
make install

if [ -e "$PHPEXTDIR/pdo_sqlsrv.so" ];then 
	echo "Creating config file"
	grep "pdo_sqlsrv.so" /usr/local/php/php.ini 2> /dev/null 1> /dev/null|| echo "extension=pdo_sqlsrv.so" >> /usr/local/php/php.ini

else
	echo "ERROR: Missing extension file $PHPEXTDIR/pdo_sqlsrv.so"
fi
