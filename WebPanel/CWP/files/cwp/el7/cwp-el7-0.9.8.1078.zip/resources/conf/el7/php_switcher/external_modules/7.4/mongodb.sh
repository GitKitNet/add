#!/bin/bash

cd /usr/local/src
yum -y install openssl-devel
rm -rf mongodb*
wget https://pecl.php.net/get/mongodb-1.5.2.tgz
tar -zxvf mongodb-1.5.2.tgz
cd mongodb-1.5.2
phpize
./configure
make
make install
grep "mongodb.so" /usr/local/php/php.ini 2> /dev/null 1> /dev/null|| echo "extension=mongodb.so" >> /usr/local/php/php.ini
