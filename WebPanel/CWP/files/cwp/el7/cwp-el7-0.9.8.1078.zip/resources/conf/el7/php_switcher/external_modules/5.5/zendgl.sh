#!/bin/bash

cd /usr/local/src
rm -rf /usr/local/zend/5.5
mkdir /usr/local/zend
mkdir /usr/local/zend/5.5
rm -rf zend-loader-php5.5-linux-x86_64
wget http://dl1.centos-webpanel.com/files/php/addons/zend-loader-php5.5-linux-x86_64.zip
unzip zend-loader-php5.5-linux-x86_64.zip
cd zend-loader-php5.5-linux-x86_64
yes | cp -rv * /usr/local/zend/5.5
rm -rf /usr/local/php/php.d/zend.ini
touch /usr/local/php/php.d/zend.ini
grep "ZendGuardLoader.so" /usr/local/php/php.d/zend.ini 2> /dev/null 1> /dev/null|| echo "zend_extension=/usr/local/zend/5.5/ZendGuardLoader.so" >> /usr/local/php/php.d/zend.ini