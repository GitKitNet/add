#!/bin/bash
if [ -e "/opt/alt/php-fpm53/usr/bin/php-config" ];then
cd /usr/local/src
yum -y remove remi-release
yum -y install epel-release
rpm -Uvh http://rpms.famillecollet.com/enterprise/remi-release-7.rpm
yum -y --enablerepo=remi,remi install redis
systemctl start redis
systemctl enable redis
rm -rf redis-3.1.1.tgz
rm -rf redis-3.1.1
wget https://pecl.php.net/get/redis-3.1.1.tgz
tar -xf redis-3.1.1.tgz
cd redis-3.1.1
/opt/alt/php-fpm53/usr/bin/phpize
./configure --with-php-config=/opt/alt/php-fpm53/usr/bin/php-config
make && make install
echo ""

PHPEXTDIR=`/opt/alt/php-fpm53/usr/bin/php-config --extension-dir`

if [ -e "$PHPEXTDIR/redis.so" ];then 
	echo "Creating config file"
	grep "redis.so" /opt/alt/php-fpm53/usr/php/php.d/redis.ini 2> /dev/null 1> /dev/null|| echo "extension=redis.so" > /opt/alt/php-fpm53/usr/php/php.d/redis.ini
else
	echo "ERROR: Missing extension file $PHPEXTDIR/redis.so"
fi
else
echo "Skipping as php build failed"
fi
