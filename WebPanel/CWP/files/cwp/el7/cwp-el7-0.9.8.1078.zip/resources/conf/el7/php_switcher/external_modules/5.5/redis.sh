#!/bin/bash

cd /usr/local/src
yum -y remove remi-release
yum -y install epel-release
rpm -Uvh http://rpms.famillecollet.com/enterprise/remi-release-7.rpm
yum -y --enablerepo=remi,remi install redis
systemctl start redis
systemctl enable redis
rm -rf redis-3.1.1.tgz
rm -rf redis-3.1.1
wget https://pecl.php.net/get/redis-3.1.1.tgz
tar -xf redis-3.1.1.tgz
cd redis-3.1.1
phpize
./configure
make && make install
echo ""
grep "redis.so" /usr/local/php/php.ini 2> /dev/null 1> /dev/null|| echo "extension=redis.so" >> /usr/local/php/php.ini
