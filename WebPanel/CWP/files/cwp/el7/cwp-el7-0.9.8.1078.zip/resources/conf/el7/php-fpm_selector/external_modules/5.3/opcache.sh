#!/bin/bash
if [ -e "/opt/alt/php-fpm53/usr/bin/php-config" ];then
cd /usr/local/src
rm -rf zendopcache-7.0.5.tgz
rm -rf zendopcache-7.0.5
wget https://pecl.php.net/get/zendopcache-7.0.5.tgz
tar -xf zendopcache-7.0.5.tgz
cd zendopcache-7.0.5
/opt/alt/php-fpm53/usr/bin/phpize
./configure --with-php-config=/opt/alt/php-fpm53/usr/bin/php-config
make && make install
echo ""

PHPEXTDIR=`/opt/alt/php-fpm53/usr/bin/php-config --extension-dir`

if [ -e "$PHPEXTDIR/opcache.so" ];then 
	echo "Creating config file"
	grep "$PHPEXTDIR/opcache.so" /opt/alt/php-fpm53/usr/php/php.d/opcache.ini 2> /dev/null 1> /dev/null|| echo "zend_extension=$PHPEXTDIR/opcache.so" > /opt/alt/php-fpm53/usr/php/php.d/opcache.ini
else
	echo "ERROR: Missing extension file $PHPEXTDIR/opcache.so"
fi
else
echo "Skipping as php build failed"
fi
