#!/bin/bash
cd /usr/local/src
yum -y remove remi-release
yum -y install epel-release
rpm -Uvh http://rpms.famillecollet.com/enterprise/remi-release-7.rpm
yum -y --enablerepo=remi,remi install redis
systemctl start redis
systemctl enable redis
rm -rf redis-2.2.4.tgz
rm -rf redis-2.2.4
wget http://pecl.php.net/get/redis-2.2.4.tgz
tar -xf redis-2.2.4.tgz
cd redis-2.2.4
phpize
./configure
make && make install
echo ""
grep "redis.so" /usr/local/php/php.ini 2> /dev/null 1> /dev/null|| echo "extension=redis.so" >> /usr/local/php/php.ini
