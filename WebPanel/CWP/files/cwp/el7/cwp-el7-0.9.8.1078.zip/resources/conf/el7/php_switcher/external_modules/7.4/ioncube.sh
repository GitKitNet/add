#!/bin/bash

cd /usr/local/src
rm -rf ioncube
rm -rf /usr/local/ioncube
mkdir /usr/local/ioncube
wget http://downloads.ioncube.com/loader_downloads/ioncube_loaders_lin_x86-64.zip
unzip ioncube_loaders_lin_x86-64.zip
cd ioncube
yes | cp -rv * /usr/local/ioncube
rm -rf /usr/local/php/php.d/ioncube.ini
touch /usr/local/php/php.d/ioncube.ini
#grep "ioncube_loader_lin_7.4.so" /usr/local/php/php.ini || echo "zend_extension=/usr/local/ioncube/ioncube_loader_lin_7.4.so" >> /usr/local/php/php.ini
# Remove OLD ioncube config (if exists)
sed -i '/ioncube_loader_lin/d' /usr/local/php/php.ini
echo "zend_extension=/usr/local/ioncube/ioncube_loader_lin_7.4.so" > /usr/local/php/php.d/ioncube.ini
