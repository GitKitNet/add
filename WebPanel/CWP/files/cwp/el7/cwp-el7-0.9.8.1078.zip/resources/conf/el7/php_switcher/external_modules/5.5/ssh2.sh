#!/bin/bash

cd /usr/local/src
rm -rf libssh2*
wget https://www.libssh2.org/download/libssh2-1.9.0.tar.gz -O libssh2.tar.gz
tar -zxvf libssh2.tar.gz
cd libssh2-*/
./configure 
make && make install
cd /usr/local/src
rm -rf ssh2*
wget https://pecl.php.net/get/ssh2-0.13.tgz -O ssh2.tgz
tar zxf ssh2.tgz
cd ssh2-*/
phpize
./configure
make
make install
echo ""
grep "ssh2.so" /usr/local/php/php.ini 2> /dev/null 1> /dev/null|| echo "extension=ssh2.so" >> /usr/local/php/php.ini



