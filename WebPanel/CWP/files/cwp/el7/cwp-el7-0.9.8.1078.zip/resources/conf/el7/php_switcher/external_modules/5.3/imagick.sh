yum -y install ImageMagick ImageMagick-devel ImageMagick-perl
cd /usr/local/src
rm -Rf imagick-3.4.3
rm -Rf imagick-3.1.2
rm -Rf imagick-3.4.3.tgz
rm -Rf imagick-3.1.2.tgz
wget http://pecl.php.net/get/imagick-3.1.2.tgz
tar zxf imagick-3.1.2.tgz
cd imagick-3.1.2
phpize
ln -s /usr/local/include/ImageMagick-6 /usr/local/include/ImageMagick
./configure
make clean
make
make install
echo ""
grep "imagick.so" /usr/local/php/php.ini 2> /dev/null 1> /dev/null|| echo "extension=imagick.so" >> /usr/local/php/php.ini
