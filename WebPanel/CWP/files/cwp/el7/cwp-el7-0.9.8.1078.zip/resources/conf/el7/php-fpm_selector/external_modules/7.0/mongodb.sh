#!/bin/bash
if [ -e "/opt/alt/php-fpm70/usr/bin/php-config" ];then
cd /usr/local/src
yum -y install openssl-devel
rm -rf mongodb-*
rm -rf mongodb-*
wget https://pecl.php.net/get/mongodb-1.5.2.tgz
tar -zxvf mongodb-1.5.2.tgz
cd mongodb-1.5.2
/opt/alt/php-fpm70/usr/bin/phpize
./configure --with-php-config=/opt/alt/php-fpm70/usr/bin/php-config
make
make install

PHPEXTDIR=`/opt/alt/php-fpm70/usr/bin/php-config --extension-dir`

if [ -e "$PHPEXTDIR/mongodb.so" ];then 
	echo "Creating config file"
	grep "mongodb.so" /opt/alt/php-fpm70/usr/php/php.d/mongodb.ini 2> /dev/null 1> /dev/null|| echo "extension=mongodb.so" > /opt/alt/php-fpm70/usr/php/php.d/mongodb.ini
else
	echo "ERROR: Missing extension file $PHPEXTDIR/mongodb.so"
fi
else
echo "Skipping as php build failed"
fi
