#!/bin/bash
if [ -e "/opt/alt/php-fpm56/usr/bin/php-config" ];then
PHPEXTDIR=`/opt/alt/php-fpm56/usr/bin/php-config --extension-dir`
if [ -e "$PHPEXTDIR/opcache.so" ];then 
echo	"Creating config file"
	grep "$PHPEXTDIR/opcache.so" /opt/alt/php-fpm56/usr/php/php.d/opcache.ini 2> /dev/null 1> /dev/null|| echo "zend_extension=$PHPEXTDIR/opcache.so" > /opt/alt/php-fpm56/usr/php/php.d/opcache.ini
else
	echo "ERROR: Missing extension file $PHPEXTDIR/opcache.so"
fi
else
echo "Skipping as php build failed"
fi
